package com.oppo.vlr.exception;

public class ChainException {
    private String code;
    private String message;

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
