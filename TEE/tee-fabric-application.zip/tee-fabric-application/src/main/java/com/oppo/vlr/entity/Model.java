//package com.oppo.vlr.entity;
//
//import lombok.Data;
//
//import java.util.List;
//
//@Data
//public class Model {
//    Integer featureSerial;
//    List<Double> data;
//}
